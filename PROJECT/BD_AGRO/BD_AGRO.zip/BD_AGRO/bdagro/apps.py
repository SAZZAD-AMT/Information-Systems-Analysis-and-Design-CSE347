from django.apps import AppConfig


class BdagroConfig(AppConfig):
    name = 'bdagro'
