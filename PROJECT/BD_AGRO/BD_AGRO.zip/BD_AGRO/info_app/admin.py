from django.contrib import admin
from .models import InfoModel


admin.site.register(InfoModel)
